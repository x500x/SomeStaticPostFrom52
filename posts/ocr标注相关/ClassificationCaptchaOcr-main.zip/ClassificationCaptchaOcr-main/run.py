
print("模型训练所有代码在development目录下")

print("极验识别代码不便公开，本套源码仅提供模型训练和图像处理代码，有需要联系：")

print("QQ: 27788854")
print("vx: taisuivip")


