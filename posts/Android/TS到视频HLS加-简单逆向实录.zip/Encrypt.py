#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os

try:
    from Cryptodome.Cipher import AES
    from Cryptodome.Util.Padding import unpad
except ImportError:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad

def decrypt_ts_file(input_path, output_path, key_bytes, iv_bytes):
    """
    解密单个 TS 文件
    :param input_path: 加密 TS 文件路径
    :param output_path: 解密后输出路径
    :param key_bytes: 16 字节密钥
    :param iv_bytes: 16 字节 IV
    """
    with open(input_path, "rb") as f:
        encrypted_data = f.read()

    cipher = AES.new(key_bytes, AES.MODE_CBC, iv=iv_bytes)
    decrypted = cipher.decrypt(encrypted_data)

    # 移除 PKCS7 填充
    try:
        decrypted = unpad(decrypted, AES.block_size)
    except ValueError:
        # 如果填充异常，手动移除末尾填充字节
        pad_len = decrypted[-1]
        if 1 <= pad_len <= 16:
            decrypted = decrypted[:-pad_len]

    with open(output_path, "wb") as f:
        f.write(decrypted)

    print(f"解密完成: {output_path} ({len(decrypted)} bytes)")

def decrypt_ts_bytes(data: bytes, key_bytes: bytes, iv_bytes: bytes) -> bytes:
    """
    解密字节流（适合内存处理）
    :return: 解密后的明文 bytes
    """
    cipher = AES.new(key_bytes, AES.MODE_CBC, iv=iv_bytes)
    decrypted = cipher.decrypt(data)

    try:
        return unpad(decrypted, AES.block_size)
    except ValueError:
        pad_len = decrypted[-1]
        if 1 <= pad_len <= 16:
            return decrypted[:-pad_len]
        return decrypted

if __name__ == "__main__":

    # 字符串密钥（16 字符）
    key_str = "sdj3nxuuw3koukvs"
    key = key_str.encode("utf-8")

    # IV（32 位 hex）
    iv = bytes.fromhex("4ff43fb9b8921a8f12fb0f3a08570689")

    # 文件路径
    input_file = "2024-08-0268.ts"      # 加密的 TS 文件
    output_file = "2024-08-0268_dec.ts" # 解密后的输出
    
    if len(sys.argv) >= 3:
        input_file = sys.argv[1]
        output_file = sys.argv[2]

    if not os.path.exists(input_file):
        print(f"[错误] 文件不存在: {input_file}")
        sys.exit(1)

    if len(key) != 16:
        print(f"[警告] 密钥长度 {len(key)} 字节，AES-128 需要 16 字节")

    decrypt_ts_file(input_file, output_file, key, iv)