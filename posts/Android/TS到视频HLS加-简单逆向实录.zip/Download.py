#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import os
import sys
import subprocess
import re
import time
from pathlib import Path

try:
    from Cryptodome.Cipher import AES
    from Cryptodome.Util.Padding import unpad
except ImportError:
    try:
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import unpad
    except ImportError:
        print("[错误] 未找到 pycryptodome 库")
        sys.exit(1)

# 工具函数
def run_cmd(cmd_list):
    result = subprocess.run(cmd_list, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr

def input_default(prompt, default=""):
    val = input(f"{prompt} [{default}]: ").strip()
    return val if val else default

def input_int_default(prompt, default=0):
    val = input(f"{prompt} [{default}]: ").strip()
    return int(val) if val.isdigit() else default

def fetch_url(url, timeout=15, headers=None):
    try:
        # 如果没有提供headers，使用默认
        if headers is None:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive'
            }
        r = requests.get(url, headers=headers, timeout=timeout)
        return r.content if r.status_code == 200 else None
    except Exception as e:
        print(f"[网络错误] {e}")
        return None

def bytes_to_hex(b):
    return b.hex()

def auto_get_key(key_url, referer=None):
    print(f"\n[自动获取] 正在请求密钥: {key_url}")
    
    # 构建请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive'
    }
    
    # 如果有referer，添加到请求头
    if referer:
        headers['Referer'] = referer
    
    data = fetch_url(key_url, headers=headers)
    
    if not data:
        print("[失败] 无法从该 URL 获取密钥")
        return None
    
    # 密钥可能是字符串或二进制数据
    try:
        # 尝试解码为字符串
        key_str = data.decode('utf-8').strip()
        print(f"[调试] 密钥原始内容: {key_str}")
        
        if len(key_str) == 16:
            print(f"[成功] 获取到字符串密钥: {key_str}")
            return bytes_to_hex(key_str.encode('utf-8'))
        elif len(key_str) == 32 and all(c in '0123456789abcdefABCDEF' for c in key_str):
            print(f"[成功] 获取到十六进制密钥: {key_str}")
            return key_str.lower()
    except UnicodeDecodeError:
        pass
    
    # 如果是二进制数据
    if len(data) == 16:
        print("[成功] 获取到标准 16 字节 AES-128 密钥")
        return bytes_to_hex(data)
    else:
        print(f"[警告] 密钥长度为 {len(data)} 字节（标准应为16字节）")
        if len(data) < 16:
            data = data.ljust(16, b'\0')
        elif len(data) > 16:
            data = data[:16]
        return bytes_to_hex(data)

def parse_m3u8_for_key(m3u8_url):
    print(f"\n[解析] 正在获取 M3U8: {m3u8_url}")
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive'
        }
        r = requests.get(m3u8_url, headers=headers, timeout=15)
        if r.status_code != 200:
            print(f"[失败] HTTP {r.status_code}")
            return None, None
        
        content = r.text
        print(f"[调试] M3U8内容前500字符:\n{content[:500]}")
        
        # 查找 #EXT-X-KEY 标签
        key_match = re.search(r'#EXT-X-KEY:[^\n]*URI="([^"]+)"', content)
        iv_match = re.search(r'#EXT-X-KEY:[^\n]*IV=0x([0-9a-fA-F]+)', content)
        
        key_url = None
        iv_hex = None
        
        if key_match:
            uri = key_match.group(1)
            print(f"[找到] 密钥URI: {uri}")
            
            # 正确处理相对路径
            if uri.startswith("http"):
                key_url = uri
            elif uri.startswith("/"):
                # 绝对路径，需要拼接域名
                base_match = re.match(r'(https?://[^/]+)', m3u8_url)
                if base_match:
                    domain = base_match.group(1)
                    key_url = domain + uri
                    print(f"[拼接] 密钥URL: {key_url}")
            else:
                # 相对路径，拼接M3U8所在目录
                base = m3u8_url.rsplit('/', 1)[0] + '/'
                key_url = base + uri
                print(f"[拼接] 密钥URL: {key_url}")
        
        if iv_match:
            iv_hex = iv_match.group(1).lower()
            print(f"[找到] IV: 0x{iv_hex}")
        
        # 如果没有找到IV，尝试从序列号推断
        if not iv_hex:
            seq_match = re.search(r'#EXT-X-MEDIA-SEQUENCE:(\d+)', content)
            if seq_match:
                seq_num = int(seq_match.group(1))
                iv_hex = f"{seq_num:032x}"
                print(f"[推断] 使用序列号作为IV: 0x{iv_hex}")
        
        return key_url, iv_hex
        
    except Exception as e:
        print(f"[错误] 解析 M3U8 失败: {e}")
        return None, None

def aes_decrypt(data, key_bytes, iv_bytes):
    cipher = AES.new(key_bytes, AES.MODE_CBC, iv=iv_bytes)
    decrypted = cipher.decrypt(data)
    
    try:
        decrypted = unpad(decrypted, AES.block_size)
    except ValueError:
        if decrypted and decrypted[-1] <= 16:
            pad_len = decrypted[-1]
            decrypted = decrypted[:-pad_len]
    
    return decrypted

def find_ts_pattern(m3u8_url, base_url):
    print(f"\n[分析] 正在分析TS文件命名模式...")
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive'
        }
        r = requests.get(m3u8_url, headers=headers, timeout=15)
        content = r.text
        
        # 查找TS文件URL
        ts_matches = re.findall(r'\n([^#\n]+\.ts)', content)
        
        if ts_matches:
            # 取第一个TS文件分析命名格式
            first_ts = ts_matches[0]
            print(f"[找到] TS文件示例: {first_ts}")
            
            # 提取文件名
            filename = first_ts.split('/')[-1]
            
            # 使用日期格式匹配
            pattern = re.search(r'^(\d{4}-\d{2}-\d{2})(\d+)(\.ts)$', filename)
            if pattern:
                prefix = pattern.group(1)

                ext = pattern.group(3)
                print(f"[分析] 前缀: '{prefix}', 扩展名: '{ext}'")
                print(f"[提示] 将从 0 开始遍历下载")
                return prefix, 0, ext
            
            # 备用方案，尝试匹配其他日期格式
            alt_pattern = re.search(r'^(\d{4}-\d{2}-\d{2})-(\d+)(\.ts)$', filename)
            if alt_pattern:
                prefix = alt_pattern.group(1) + '-'
                ext = alt_pattern.group(3)
                print(f"[分析] 前缀: '{prefix}', 扩展名: '{ext}'")
                print(f"[提示] 将从 0 开始遍历下载")
                return prefix, 0, ext
            
            # 最后的备用方案
            matches = re.findall(r'\d+', filename)
            if matches:
                num_str = matches[-1]
                prefix = filename[:filename.rfind(num_str)]
                ext = '.ts'
                print(f"[分析] 前缀: '{prefix}', 扩展名: '{ext}'")
                print(f"[提示] 将从 0 开始遍历下载")
                return prefix, 0, ext
        
        print("[提示] 无法从M3U8确定命名模式，将使用用户输入")
        return None, 0, ".ts"
        
    except Exception as e:
        print(f"[警告] 分析TS模式失败: {e}")
        return None, 0, ".ts"

# 主程序

def main():
    print("=" * 60)
    print("  M3U8 TS 批量下载解密合并工具")
    print("=" * 60)
    print()
    
    # 基础配置
    print("--- 步骤 1/5: 基础配置 ---")
    
    m3u8_url = input_default("请输入 M3U8 文件的完整 URL", "")
    if not m3u8_url:
        print("[错误] 必须提供 M3U8 URL")
        return
    
    # 分析TS文件命名模式
    ts_prefix, default_start, ts_ext = find_ts_pattern(m3u8_url, "")
    
    # 获取TS文件的基础URL
    if "://" in m3u8_url:
        base_url = m3u8_url.rsplit('/', 1)[0] + '/'
        print(f"[提示] 自动推导基础URL: {base_url}")
    else:
        base_url = input_default("TS 文件的基础 URL", "")
    
    if not base_url.endswith('/'):
        base_url += '/'
    
    # 获取文件名前缀
    if ts_prefix is not None:
        date_str = input_default("TS 文件名前缀", ts_prefix)
    else:
        date_str = input_default("TS 文件名前缀（如 2024-07-31/ 或 segment_）", "")
    
    # 起始编号
    start_num = input_int_default("起始分段编号", default_start)
    
    # 连续404停止阈值
    max_404 = input_int_default("连续遇到 404 后停止的数量", 3)
    print()
    
    # 密钥获取
    print("--- 步骤 2/5: 解密密钥配置 ---")
    print("请选择密钥获取方式:")
    print("  [1] 自动从 M3U8 文件解析（推荐）")
    print("  [2] 手动输入密钥 URL")
    print("  [3] 手动输入密钥内容")
    
    choice = input_default("请选择 (1/2/3)", "1")
    key_hex = None
    iv_hex = None
    
    if choice == "1":
        key_url, iv_hex = parse_m3u8_for_key(m3u8_url)
        if key_url:
            key_hex = auto_get_key(key_url, m3u8_url)  # 传入referer
        if not key_hex:
            print("[警告] 自动解析失败，请选择其他方式")
            choice = "3"
    
    if choice == "2":
        key_url = input_default("请输入密钥文件的 URL", "")
        if key_url:
            key_hex = auto_get_key(key_url, m3u8_url)  # 传入referer
        if not key_hex:
            print("[警告] 无法获取密钥，将切换到手动输入")
            choice = "3"
    
    if choice == "3" or not key_hex:
        print("\n[手动输入] 请提供密钥信息")
        print("  密钥可以是：")
        print("  - 16字符的字符串（如: mysecretkey12345）")
        print("  - 32位十六进制（如: 00112233445566778899aabbccddeeff）")
        
        key_input = input_default("请输入密钥", "")
        if not key_input:
            print("[错误] 必须提供密钥")
            return
        
        if len(key_input) == 32 and all(c in '0123456789abcdefABCDEF' for c in key_input):
            key_hex = key_input.lower()
            print("[确认] 使用十六进制密钥")
        else:
            key_bytes = key_input.encode('utf-8')
            if len(key_bytes) != 16:
                print(f"[警告] 密钥长度 {len(key_bytes)} 字节，标准AES-128应为16字节")
                if len(key_bytes) < 16:
                    key_bytes = key_bytes.ljust(16, b'\0')
                elif len(key_bytes) > 16:
                    key_bytes = key_bytes[:16]
            key_hex = bytes_to_hex(key_bytes)
            print(f"[确认] 转换后密钥(hex): {key_hex}")
    
    # 获取IV
    if not iv_hex:
        print("\n[IV 配置] IV（初始化向量）通常是16字节十六进制")
        print("  如果不知道IV，可以尝试：")
        print("  - 留空使用全零IV")
        print("  - 输入 'auto' 尝试自动生成")
        
        iv_input = input_default("请输入 IV (32位hex，留空使用全零)", "")
        
        if iv_input.lower() == 'auto':
            iv_hex = f"{start_num:032x}"
            print(f"[自动] 使用起始编号生成IV: {iv_hex}")
        elif iv_input:
            iv_hex = iv_input.lower().replace("0x", "")
            if len(iv_hex) < 32:
                iv_hex = iv_hex.zfill(32)
            elif len(iv_hex) > 32:
                iv_hex = iv_hex[:32]
        else:
            iv_hex = "00000000000000000000000000000000"
            print("[提示] 使用全零IV")
    
    # 转换为 bytes
    try:
        key_bytes = bytes.fromhex(key_hex)
        iv_bytes = bytes.fromhex(iv_hex)
    except ValueError as e:
        print(f"[错误] 密钥或IV格式错误: {e}")
        return
    
    print(f"\n[配置确认]")
    print(f"  密钥 (hex): {key_hex}")
    print(f"  IV   (hex): {iv_hex}")
    print(f"  密钥长度:   {len(key_bytes)} 字节")
    print(f"  基础URL:    {base_url}")
    print(f"  文件前缀:   {date_str}")
    print()
    
    # 下载配置
    print("--- 步骤 3/5: 下载配置 ---")
    output_dir = input_default("输出文件夹名", "ts_downloaded")
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    print("\n[检查依赖]")
    ret, _, _ = run_cmd(["ffmpeg", "-version"])
    if ret != 0:
        print("[警告] 未检测到 ffmpeg，合并功能将不可用")
        cont = input_default("是否继续下载（不合并）? (y/n)", "y")
        if cont.lower() != 'y':
            return
    else:
        print("[成功] ffmpeg 已安装")
    print()
    
    # 开始遍历下载
    print("--- 步骤 4/5: 开始下载 ---")
    print("按 Ctrl+C 可随时中断\n")
    
    consecutive_404 = 0
    downloaded = 0
    failed = []
    
    i = start_num
    while consecutive_404 < max_404:
        filename = f"{date_str}{i}{ts_ext}"
        url = base_url + filename
        
        print(f"[下载] {filename}...", end='', flush=True)
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Referer': m3u8_url
            }
            r = requests.get(url, headers=headers, timeout=15)
        except Exception as e:
            print(f"[错误] 网络错误: {e}")
            consecutive_404 += 1
            failed.append(i)
            i += 1
            continue
        
        if r.status_code == 404:
            print(f"[错误] 404 不存在 ({consecutive_404 + 1}/{max_404})")
            consecutive_404 += 1
            i += 1
            continue
        elif r.status_code != 200:
            print(f"[错误] HTTP {r.status_code}")
            consecutive_404 += 1
            failed.append(i)
            i += 1
            continue
        
        consecutive_404 = 0
        
        dec_path = os.path.join(output_dir, f"{i:04d}.ts")
        
        try:
            decrypted = aes_decrypt(r.content, key_bytes, iv_bytes)
            with open(dec_path, "wb") as f:
                f.write(decrypted)
            downloaded += 1
            print(f"[恭喜] 解密成功 ({len(decrypted)} bytes)")
        except Exception as e:
            print(f"[错误] 解密失败: {e}")
            enc_path = os.path.join(output_dir, f"{i:04d}_enc.ts")
            with open(enc_path, "wb") as f:
                f.write(r.content)
            print(f"      已保存加密文件: {enc_path}")
            failed.append(i)
        
        i += 1
        time.sleep(0.1)
    
    print(f"\n[下载完成] 成功下载并解密: {downloaded} 个片段")
    if failed:
        print(f"[注意] 失败/跳过: {len(failed)} 个 (编号: {failed[:10]}{'...' if len(failed)>10 else ''})")
    
    if downloaded == 0:
        print("[错误] 没有下载到任何片段，退出")
        return
    
    # 合并视频
    print("\n--- 步骤 5/5: 合并视频 ---")
    
    ts_files = sorted([
        f for f in os.listdir(output_dir) 
        if f.endswith(".ts") and not f.endswith("_enc.ts")
    ])
    
    if not ts_files:
        print("[错误] 没有可用的 TS 片段，退出")
        return
    
    print(f"发现 {len(ts_files)} 个 TS 片段，准备合并...")
    
    filelist_path = os.path.join(output_dir, "filelist.txt")
    with open(filelist_path, "w") as f:
        for ts in ts_files:
            abs_path = os.path.abspath(os.path.join(output_dir, ts))
            f.write(f"file '{abs_path}'\n")
    
    default_name = f"output_{int(time.time())}.mp4"
    output_mp4 = input_default("输出视频文件名", default_name)
    
    if not output_mp4.endswith('.mp4'):
        output_mp4 += '.mp4'
    
    print(f"\n[合并] 正在使用 ffmpeg 合并...")
    print(f"  输入文件: {len(ts_files)} 个")
    print(f"  输出文件: {output_mp4}")
    
    ret, out, err = run_cmd([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", filelist_path,
        "-c", "copy",
        "-bsf:a", "aac_adtstoasc",
        output_mp4
    ])
    
    if ret == 0 and os.path.exists(output_mp4):
        size_mb = os.path.getsize(output_mp4) / (1024 * 1024)
        print(f"\n[恭喜] 合并成功!")
        print(f"  文件: {os.path.abspath(output_mp4)}")
        print(f"  大小: {size_mb:.2f} MB")
        print(f"  时长: 约 {len(ts_files) * 10} 秒 (假设每个片段10秒)")
        
        clean = input_default("是否删除临时文件? (y/n)", "y")
        if clean.lower() == "y":
            os.remove(filelist_path)
            for f in ts_files:
                os.remove(os.path.join(output_dir, f))
            try:
                os.rmdir(output_dir)
                print("[清理] 临时文件夹已删除")
            except:
                print("[提示] 临时文件夹非空，未删除")
    else:
        print(f"\n[错误] 合并失败!")
        print(f"错误信息: {err.strip()[:500]}")
        print(f"filelist.txt 已保留在: {filelist_path}")
        print("你可以手动运行以下命令合并:")
        print(f"  ffmpeg -f concat -safe 0 -i '{filelist_path}' -c copy output.mp4")
    
    print("\n" + "=" * 60)
    print("  处理完成")
    print("=" * 60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[中断] 用户取消操作")
        sys.exit(0)
    except Exception as e:
        print(f"\n[致命错误] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
