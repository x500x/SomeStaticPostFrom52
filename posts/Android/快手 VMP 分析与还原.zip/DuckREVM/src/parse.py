import json
import sys
from collections.abc import Iterator
from typing import Any


class TraceParser:
    """解析 code.log（TSV 7列）为原子 JSON 对象，支持流式处理超大文件。"""

    def __init__(self, filepath: str, encoding: str = "utf-8", errors: str = "replace"):
        """
        Args:
            filepath: 日志文件路径
            encoding: 文件编码
            errors: 编码错误处理策略
        """
        self.filepath = filepath
        self.encoding = encoding
        self.errors = errors
        self.total_processed = 0

    @staticmethod
    def parse_json_obj(s: str) -> dict[str, Any]:
        """解析 TSV 中的 JSON 列；空串/非法内容回退为空 dict。"""
        s = s.strip()
        if not s or s == "{}":
            return {}
        try:
            v = json.loads(s)
            return v if isinstance(v, dict) else {}
        except ValueError:
            return {}

    @staticmethod
    def parse_line(line: str) -> dict[str, Any]:
        """将一行 TSV 转为原子 JSON 对象（dict）。"""
        line = line.rstrip("\n")
        parts = line.split("\t")
        # 若列数不足，补空字符串，防止 IndexError（可选增强）
        while len(parts) < 7:
            parts.append("")
        seq, pc, off, asm, read, write, syscall = parts[:7]
        return {
            "type": "insn",
            "seq": seq.strip(),
            "pc": pc.strip(),
            "off": off.strip(),
            "asm": asm.strip('" '),
            "read": TraceParser.parse_json_obj(read),
            "write": TraceParser.parse_json_obj(write),
            "syscall": TraceParser.parse_json_obj(syscall),
        }

    def iter_atomic_objects(self) -> Iterator[dict[str, Any]]:
        """生成器：逐行读取文件，yield 解析后的 dict（跳过 '===' 行）。"""
        with open(self.filepath, encoding=self.encoding, errors=self.errors) as f:
            for line in f:
                if line.startswith("==="):
                    continue
                yield self.parse_line(line)

    def iter_json_lines(self, **json_dumps_kwargs) -> Iterator[str]:
        """
        生成器：yield 紧凑 JSON 字符串（NDJSON 格式）。
        可传入 json.dumps 的额外参数（如 indent）覆盖默认。
        """
        # 默认使用紧凑格式（与原文一致）
        default_kwargs = {"ensure_ascii": False, "separators": (",", ":")}
        default_kwargs.update(json_dumps_kwargs)

        for obj in self.iter_atomic_objects():
            yield json.dumps(obj, **default_kwargs)

    def process(
        self,
        output=sys.stdout,
        report_interval: int = 2_000_000,
        quiet: bool = False,
    ) -> int:
        """
        核心处理方法：逐条输出 JSON 到指定输出流，并打印进度到 stderr。

        Args:
            output: 输出流（默认 stdout）
            report_interval: 每处理 N 条打印一次进度
            quiet: 是否禁止进度输出

        Returns:
            处理的总条数
        """
        self.total_processed = 0
        try:
            for json_str in self.iter_json_lines():
                output.write(json_str + "\n")
                self.total_processed += 1

                if not quiet and self.total_processed % report_interval == 0:
                    print(
                        f"  已处理 {self.total_processed:,} 条...",
                        file=sys.stderr,
                    )
        except BrokenPipeError:
            # 如果管道被提前关闭（例如 head），安静退出
            sys.stderr.close()
            sys.exit(0)

        return self.total_processed
