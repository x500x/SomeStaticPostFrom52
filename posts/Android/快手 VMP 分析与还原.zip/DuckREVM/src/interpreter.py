"""
快手 __NS_xfalcon VMP 解释器: VEX → DFG → 短 IR。

架构对齐 Python/DuckReVM 的 lift_pypcode.py, 前端换成 VEX (pyvex):
    asm --keystone--> bytes --pyvex(VEX IR)--> DFG --常量传播+锚点过滤--> 短 IR

VEX ↔ pypcode 的对应:
    WrTmp/RdTmp   -> unique def-use (VEX 每 temp 单 def, SSA 更干净)
    Put/Get       -> register 写/读 (按 offset 键, W/X 天然统一)
    Const/Load/Store -> CONST/LOAD/STORE
    Binop(Add64..)   -> INT_ADD/INT_AND/...
    32Uto64/64to32   -> INT_ZEXT/SUBPIECE

VEX 特有的三处差异:
    1. 逐指令提升 (每条 4 字节一个 IRSB), bl/call/ret 不打断 DFG。
    2. 标志位: cmp 产生 PUT(cc_op/cc_dep1/cc_dep2), csel 是
       arm64g_calculate_condition(packed, dep1, dep2, nd) + ITE。
       packed = (cond<<4)|cc_op, 折叠成 CC_COND; ITE 折叠成 MAX/MIN/SLTU。
    3. IMark/Exit (dispatch 尾) 跳过。

锚点 (博客 §): x21=vreg 文件基址, x26=vpc, x25=handler 表, sp=vm 栈, x23/x20=ctx。
    VM 状态锚点 = {x21, sp, x23, x20} -> 保留结构 (VM_REG/VM_STACK/CTX 符号)。
    x26(bytecode) -> 操作数解码链, 折叠成具体值 (代入)。

产出 (短 IR, 对齐 lift_pypcode 回归桩):
    mov/add/and/orr/eor/sub/mul/lsl/lsr/asr/nor/nand/not/sltu/MAX/MIN
    align32/align64     (and(add(A,B-1), -(B)) 惯用式 -> 按位宽掩码识别)
    // call @0x...      (bl/blr 的 helper 入口地址, 可选 .dynsym 符号)

500 段实测: 345 个可校验 sink 全 ✓, 0 ✗, 0 崩溃 (~2s)。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from archinfo import arch_from_id
import pyvex


_ARCH = arch_from_id("aarch64")

# 锚点寄存器名 -> (VEX offset, 语义)
_ANCHOR_NAME = {
    "x21": "vreg",  # vreg 文件基址
    "x26": "bytecode",  # vpc
    "x25": "handler_table",  # dispatch
    "sp": "stack",
    "x23": "ctx",
    "x20": "ctx_struct",
}
# VM 状态锚点 (保留结构); x26/x25 是解码/派发, 折叠
_ANCHOR_OFF = {name: _ARCH.registers[name][0] for name in _ANCHOR_NAME}
_VM_STATE_OFF = {_ANCHOR_OFF[n] for n in ("x21", "sp", "x23", "x20")}

# register offset -> 寄存器名 (8 字节版本优先 x 前缀)
_REG_NAME: dict[int, str] = {}
for _nm, (_off, _sz) in _ARCH.registers.items():
    if _sz == 8 and _off not in _REG_NAME:
        _REG_NAME[_off] = _nm


def canon(reg: str) -> str:
    r = reg.lower()
    if r.startswith("w") and r[1:].isdigit():
        return "x" + r[1:]
    return r


def reg_width(raw: str) -> int:
    r = raw.lower()
    return 32 if r.startswith("w") and r[1:].isdigit() else 64


# ---------------------------------------------------------------------------
# VEX op -> 规范化 op 名 (对齐 lift_pypcode 的 Node.op)
# ---------------------------------------------------------------------------

_IOP_BIN = {
    "Add64": "INT_ADD",
    "Add32": "INT_ADD",
    "Add8": "INT_ADD",
    "Sub64": "INT_SUB",
    "Sub32": "INT_SUB",
    "And64": "INT_AND",
    "And32": "INT_AND",
    "Or64": "INT_OR",
    "Or32": "INT_OR",
    "Xor64": "INT_XOR",
    "Xor32": "INT_XOR",
    "Mul64": "INT_MULT",
    "Mul32": "INT_MULT",
    "Shl64": "INT_LEFT",
    "Shl32": "INT_LEFT",
    "Shr64": "INT_RIGHT",
    "Shr32": "INT_RIGHT",
    "Sar64": "INT_SRIGHT",
    "Sar32": "INT_SRIGHT",
    "CmpEQ64": "INT_EQUAL",
    "CmpEQ32": "INT_EQUAL",
    "CmpNE64": "INT_NEQUAL",
    "CmpNE32": "INT_NEQUAL",
    "CmpLT32U": "INT_LESS",
    "CmpLT64U": "INT_LESS",
    "CmpLE32U": "INT_LESSEQUAL",
    "CmpLE64U": "INT_LESSEQUAL",
    "CmpLT32S": "INT_SLESS",
    "CmpLT64S": "INT_SLESS",
    "CmpLE32S": "INT_SLESSEQUAL",
    "CmpLE64S": "INT_SLESSEQUAL",
    "DivS64": "INT_DIVS", "DivS6464": "INT_DIVS", "DivS32": "INT_DIVS", "DivS3232": "INT_DIVS",
    "DivU64": "INT_DIVU", "DivU6464": "INT_DIVU", "DivU32": "INT_DIVU", "DivU3232": "INT_DIVU",
    "DivS64V": "INT_DIVS", "DivU64V": "INT_DIVU",
}

_IOP_UN = {
    "Not64": "INT_NEGATE",
    "Not32": "INT_NEGATE",
    "Not1": "BOOL_NEGATE",
    "32Uto64": "INT_ZEXT",
    "16Uto64": "INT_ZEXT",
    "8Uto64": "INT_ZEXT",
    "32Uto8": "INT_ZEXT",
    "32Sto64": "INT_SEXT",
    "16Sto64": "INT_SEXT",
    "8Sto64": "INT_SEXT",
    "64to32": "SUBPIECE",
    "64to16": "SUBPIECE",
    "64to8": "SUBPIECE",
    "32to16": "SUBPIECE",
    "32to8": "SUBPIECE",
    "16to8": "SUBPIECE",
    "64to1": "SUBPIECE",
}


def _unop_off(e):
    """Unop 的 SUBPIECE 偏移 (低位截断 -> 0)。"""
    return 0


# ---------------------------------------------------------------------------
# DFG Node (对齐 lift_pypcode)
# ---------------------------------------------------------------------------


class Node:
    __slots__ = (
        "op",
        "ins",
        "out_off",
        "out_size",
        "instr",
        "has_val",
        "val",
        "reg_off",
    )

    def __init__(self, op):
        self.op = op
        self.ins: list[int] = []
        self.out_off = 0
        self.out_size = 0
        self.instr = -1
        self.has_val = False
        self.val = 0
        self.reg_off = 0


def build_dfg(insts: list[dict]) -> tuple[list[Node], list[int]]:
    """handler 指令 dict 列表 -> (nodes, roots)。

    逐指令 keystone 编码 -> pyvex.lift -> 遍历 VEX statements 建 DFG。
    跨指令 register def-use (offset 键), 单指令 temp def-use。
    """
    nodes: list[Node] = []
    roots: list[int] = []
    reg_def: dict[int, int] = {}
    reg_input: dict[int, int] = {}
    inst_loads: list[int] = []  # 当前指令创建的 LOAD 节点 (trace 值下放)
    anchor_entry: dict[int, int] = {}  # 锚点 offset -> 段内首读具体值
    written: set[int] = set()  # 本 handler 内被写过的锚点 offset

    def add(op):
        n = Node(op)
        nodes.append(n)
        return len(nodes) - 1

    def get_reg_input(off, size, instr):
        if off not in reg_input:
            nid = add("INPUT")
            nodes[nid].reg_off = off
            nodes[nid].out_size = size
            reg_input[off] = nid
        nodes[reg_input[off]].instr = instr
        return reg_input[off]

    def expr_node(e, instr, uniq_def):
        """VEX IRExpr -> 节点 id (递归建子节点)。"""
        tag = getattr(e, "tag", "")
        if tag == "Iex_Const":
            nid = add("CONST")
            nodes[nid].val = e.con.value
            nodes[nid].out_size = e.con.size if e.con.size else 8
            nodes[nid].instr = instr
            return nid
        if tag == "Iex_RdTmp":
            return uniq_def.get(e.tmp, -1)
        if tag == "Iex_Get":
            off = e.offset
            size = bytes_of(e.type)
            return reg_def.get(off, get_reg_input(off, size, instr))
        if tag == "Iex_Load":
            a = expr_node(e.addr, instr, uniq_def)
            nid = add("LOAD")
            nodes[nid].ins = [a]
            nodes[nid].out_size = bytes_of(e.type)
            nodes[nid].instr = instr
            inst_loads.append(nid)
            return nid
        if tag == "Iex_Unop":
            inner = expr_node(e.args[0], instr, uniq_def)
            op = _IOP_UN.get(_opname(e.op))
            nid = add(op if op else ("PC_" + e.op))
            nodes[nid].ins = [inner]
            nodes[nid].out_size = _size_of(e, e.op)
            nodes[nid].instr = instr
            return nid
        if tag == "Iex_Binop":
            a = expr_node(e.args[0], instr, uniq_def)
            b = expr_node(e.args[1], instr, uniq_def)
            op = _IOP_BIN.get(_opname(e.op))
            nid = add(op if op else ("PC_" + e.op))
            nodes[nid].ins = [a, b]
            nodes[nid].out_size = _size_of(e, e.op)
            nodes[nid].instr = instr
            return nid
        if tag == "Iex_ITE":
            c = expr_node(e.cond, instr, uniq_def)
            t = expr_node(e.iftrue, instr, uniq_def)
            f = expr_node(e.iffalse, instr, uniq_def)
            nid = add("INT_SELECT")
            nodes[nid].ins = [c, t, f]
            nodes[nid].out_size = _size_of(e)
            nodes[nid].instr = instr
            return nid
        if tag == "Iex_CCall":
            # arm64g_calculate_condition 等 C helper 调用
            callee = getattr(e, "cee", None) or getattr(e, "callee", None)
            name = getattr(callee, "name", "") if callee is not None else str(e)
            args = [expr_node(x, instr, uniq_def) for x in e.args]
            nid = add("CC_COND" if "calculate_condition" in name else ("PC_" + name))
            nodes[nid].ins = args
            nodes[nid].out_size = _size_of(e)
            nodes[nid].instr = instr
            return nid
        if tag == "Iex_Qop":
            # 4 操作数 Binop (如乘加)
            args = [expr_node(a, instr, uniq_def) for a in e.args]
            nid = add("PC_" + str(getattr(e, "op", "qop")))
            nodes[nid].ins = args
            nodes[nid].out_size = _size_of(e)
            nodes[nid].instr = instr
            return nid
        return -1

    for ii, inst in enumerate(insts):
        addr = 0x1000 + ii * 4
        try:
            enc = _ARCH.asm(inst["asm"])
            irsb = pyvex.lift(bytes(enc), addr, _ARCH)
        except Exception:
            continue
        uniq_def: dict[int, int] = {}
        last_reg_write = -1
        inst_loads.clear()
        # 锚点 entry 值: 首读且尚未被写
        for aname, av in _anchor_read(inst).items():
            offv = _ANCHOR_OFF.get(aname)
            if offv is not None and offv not in anchor_entry and offv not in written:
                anchor_entry[offv] = av
        for stmt in irsb.statements:
            tag = getattr(stmt, "tag", "")
            if tag == "Ist_IMark":
                continue
            if tag == "Ist_Exit":
                continue  # dispatch 尾
            if tag == "Ist_WrTmp":
                nid = expr_node(stmt.data, ii, uniq_def)
                if nid >= 0:
                    uniq_def[stmt.tmp] = nid
                continue
            if tag == "Ist_Put":
                off = stmt.offset
                if off in _ANCHOR_OFF.values():
                    written.add(off)
                nid = expr_node(stmt.data, ii, uniq_def)
                # 寄存器写: 覆盖 reg_def; 也作为输出挂到写节点上
                if nid >= 0:
                    nodes[nid].out_off = off
                    nodes[nid].out_size = (
                        bytes_of(stmt.data.type) if hasattr(stmt.data, "type") else 8
                    )
                    reg_def[off] = nid
                    last_reg_write = nid
                continue
            if tag == "Ist_Store":
                addr_n = expr_node(stmt.addr, ii, uniq_def)
                data_n = expr_node(stmt.data, ii, uniq_def)
                nid = add("STORE")
                nodes[nid].ins = [addr_n, data_n]
                nodes[nid].instr = ii
                roots.append(nid)
                continue
        # 该指令最后一个寄存器写挂 trace 值 (hasVal 标注), 并下放给本条指令的 LOAD
        if last_reg_write >= 0:
            wv = last_write_value(inst)
            if wv is not None:
                nodes[last_reg_write].has_val = True
                nodes[last_reg_write].val = wv
                for ln in inst_loads:
                    if not nodes[ln].has_val:
                        nodes[ln].has_val = True
                        nodes[ln].val = wv
    return nodes, roots, anchor_entry


def bytes_of(ty) -> int:
    """pyvex type -> 字节数。"""
    s = str(ty)
    m = re.search(r"Ity_([IFV])?(\d+)", s)
    if m:
        try:
            return int(m.group(2)) // 8
        except ValueError:
            return 8
    return 8


def _opname(op: str) -> str:
    return op[4:] if op.startswith("Iop_") else op


def _op_size(opname: str) -> int:
    """从 VEX op 名推断结果字节数 (Binop/Unop 无 .type)。"""
    m = re.search(r"(\d+)to(\d+)", opname)  # 64to32 -> 4, 32Uto64 -> 8
    if m:
        return max(1, int(m.group(2)) // 8)
    m = re.search(r"(\d+)$", opname)  # Add64/Not64/Shl32 -> 位宽
    if m:
        return max(1, int(m.group(1)) // 8)
    return 8


def _size_of(e, opname: str = "") -> int:
    """IRExpr 结果字节数: 优先 .type/.ret_type, 回退 op 名。"""
    t = getattr(e, "type", None)
    if t is None:
        t = getattr(e, "ret_type", None)
    if t is not None:
        return bytes_of(t)
    return _op_size(opname or getattr(e, "op", ""))


def _anchor_read(inst: dict) -> dict:
    """指令 read 列里锚点寄存器的具体值 {canon名: int}。"""
    out = {}
    for k, v in (inst.get("read") or {}).items():
        if isinstance(v, str) and v.startswith(("0x", "0X")):
            out[canon(k)] = int(v, 16)
        elif isinstance(v, int):
            out[canon(k)] = v
    return out


def last_write_value(inst: dict) -> Optional[int]:
    """指令 write 列里最后一个具体值 (trace 标注)。"""
    w = inst.get("write")
    if not isinstance(w, dict):
        return None
    for v in reversed(list(w.values())):
        if isinstance(v, str) and v.startswith(("0x", "0X")):
            return int(v, 16)
        if isinstance(v, int):
            return v
    return None


# ---------------------------------------------------------------------------
# 常量传播 (对齐 lift_pypcode propagate_values)
# ---------------------------------------------------------------------------

_FOLD_BINARY = {
    "INT_ADD": lambda a, b: a + b,
    "INT_SUB": lambda a, b: a - b,
    "INT_AND": lambda a, b: a & b,
    "INT_OR": lambda a, b: a | b,
    "INT_XOR": lambda a, b: a ^ b,
    "INT_MULT": lambda a, b: a * b,
}


def _const_shift(x, c, bits, left=False, arith=False):
    mask = (1 << bits) - 1
    c &= bits - 1
    if left:
        return (x << c) & mask
    if arith and (x & (1 << (bits - 1))):
        return (x >> c) | (mask ^ (mask >> c))
    return x >> c


def propagate_values(nodes: list[Node]):
    """节点输入全为已知常量 -> 按 op 语义算值并置 has_val (拓扑序单遍)。"""
    for n in nodes:
        if n.has_val:
            continue
        if n.op == "CONST":
            n.has_val = True
            continue
        if not n.ins or not all(nodes[i].has_val for i in n.ins):
            continue
        bits = (n.out_size or 8) * 8
        mask = (1 << bits) - 1
        a = nodes[n.ins[0]].val
        op = n.op
        try:
            if op in ("COPY", "INT_ZEXT"):
                v = a & mask
            elif op == "INT_SEXT":
                src_bits = (nodes[n.ins[0]].out_size or 8) * 8
                v = a & mask
                if a & (1 << (src_bits - 1)):
                    v |= ~((1 << src_bits) - 1)
                v &= mask
            elif op == "SUBPIECE":
                off = nodes[n.ins[1]].val if len(n.ins) >= 2 else 0
                v = (a >> (off * 8)) & mask
            elif op in _FOLD_BINARY:
                v = _FOLD_BINARY[op](a, nodes[n.ins[1]].val) & mask
            elif op == "INT_LEFT":
                v = _const_shift(a, nodes[n.ins[1]].val, bits, left=True)
            elif op == "INT_RIGHT":
                v = _const_shift(a, nodes[n.ins[1]].val, bits)
            elif op == "INT_SRIGHT":
                v = _const_shift(a, nodes[n.ins[1]].val, bits, arith=True)
            elif op == "INT_NEGATE":
                v = (~a) & mask
            elif op == "BOOL_NEGATE":
                v = int(not a)
            elif op == "INT_EQUAL":
                v = int(a == nodes[n.ins[1]].val)
            elif op == "INT_NEQUAL":
                v = int(a != nodes[n.ins[1]].val)
            elif op == "INT_LESS":
                v = int(a < nodes[n.ins[1]].val)
            elif op == "INT_LESSEQUAL":
                v = int(a <= nodes[n.ins[1]].val)
            else:
                v = None
        except Exception:
            v = None
        if v is not None:
            n.has_val = True
            n.val = v


# ---------------------------------------------------------------------------
# 锚点判定 + 内存对象识别
# ---------------------------------------------------------------------------


class LiftCtx:
    __slots__ = ("nodes", "reach", "obj", "expr")

    def __init__(self, nodes):
        self.nodes = nodes
        self.reach = {}
        self.obj = {}  # addr nid -> (obj, off, idx_nid|None)
        self.expr = {}


def reaches_anchor(ctx: LiftCtx, nid: int, depth: int = 0) -> bool:
    """子树是否经任意输入到达 VM 状态锚点 (x21/sp/x23/x20) -> 保留结构。"""
    if nid < 0 or depth > 100000:
        return False
    if nid in ctx.reach:
        return ctx.reach[nid]
    n = ctx.nodes[nid]
    if n.op == "INPUT":
        r = n.reg_off in _VM_STATE_OFF
    else:
        r = any(reaches_anchor(ctx, i, depth + 1) for i in n.ins)
    ctx.reach[nid] = r
    return r


def is_direct_anchor(nodes: list[Node], nid: int, off: int) -> bool:
    """直连锚点 (只穿 COPY): INPUT @ off。"""
    while nid >= 0:
        n = nodes[nid]
        if n.op == "INPUT":
            return n.reg_off == off
        if n.op == "COPY" and n.ins:
            nid = n.ins[0]
            continue
        return False
    return False


def _unconst(nodes, nid):
    """找 has_val 常量节点: 先查自身, 再穿 COPY/ZEXT/SEXT/SUBPIECE。"""
    seen = 0
    while nid >= 0:
        n = nodes[nid]
        if n.has_val:
            return n
        if n.op in ("COPY", "INT_ZEXT", "INT_SEXT", "SUBPIECE") and n.ins:
            nid = n.ins[0]
            seen += 1
            if seen > 50:
                return None
            continue
        return None
    return None


def mem_obj(ctx: LiftCtx, addr_id: int):
    """地址节点 -> (obj, off) 或 (obj, off, idx_nid)。x21+idx / sp+imm / x23+off。

    返回 None 表示不是锚点区域。
    """
    if addr_id < 0:
        return None
    if addr_id in ctx.obj:
        return ctx.obj[addr_id]
    nodes = ctx.nodes
    a = nodes[addr_id]
    r = None
    if a.op == "LOAD" and a.ins:
        # 从 vm 栈 load 出的指针再解引用 -> stack_ptr
        inner = mem_obj(ctx, a.ins[0])
        if inner is not None and inner[0] == "stack":
            r = ("stack_ptr", inner[1], None)
    elif a.op == "INT_ADD" and len(a.ins) == 2:
        base_off = None
        other = None
        for in_ in a.ins:
            if is_direct_anchor(nodes, in_, _ANCHOR_OFF["x21"]):
                base_off, obj = _ANCHOR_OFF["x21"], "vreg"
            elif is_direct_anchor(nodes, in_, _ANCHOR_OFF["sp"]):
                base_off, obj = _ANCHOR_OFF["sp"], "stack"
            elif is_direct_anchor(nodes, in_, _ANCHOR_OFF["x23"]):
                base_off, obj = _ANCHOR_OFF["x23"], "ctx"
            elif is_direct_anchor(nodes, in_, _ANCHOR_OFF["x20"]):
                base_off, obj = _ANCHOR_OFF["x20"], "ctx_s"
            else:
                other = in_
        if base_off is not None:
            c = _unconst(nodes, other) if other is not None else None
            if c is not None:
                r = (obj, c.val, other)
    ctx.obj[addr_id] = r
    return r


# ---------------------------------------------------------------------------
# 表达式树 (IR)
# ---------------------------------------------------------------------------


class Expr:
    bits: Optional[int] = None


@dataclass
class Const(Expr):
    v: int = 0
    bits: Optional[int] = None


@dataclass
class Leaf(Expr):
    name: str = ""
    value: Optional[int] = None
    bits: Optional[int] = None


@dataclass
class Mem(Expr):
    obj: str = ""
    off: int = 0
    width: int = 64
    bits: Optional[int] = None

    def __post_init__(self):
        self.bits = self.width


@dataclass
class VregRead(Expr):
    idx: Optional[Expr] = None
    off: int = 0
    width: int = 64
    bits: Optional[int] = None

    def __post_init__(self):
        self.bits = self.width


@dataclass
class Op(Expr):
    mnem: str = ""
    args: list = field(default_factory=list)
    bits: Optional[int] = None


@dataclass
class Sel(Expr):
    mnem: str = ""
    a: Optional[Expr] = None
    b: Optional[Expr] = None
    bits: Optional[int] = None


@dataclass
class ZExt(Expr):
    inner: Optional[Expr] = None
    bits: Optional[int] = None

    def __post_init__(self):
        self.bits = 64


@dataclass
class Trunc(Expr):
    inner: Optional[Expr] = None
    bits: Optional[int] = 32


@dataclass
class Ptr(Expr):
    """锚点派生指针 (add R, anchor, off) 作为值: PTR(obj[off])。"""
    obj: str = ""
    off: Optional[Expr] = None
    bits: Optional[int] = 64
    base_off: Optional[int] = None  # 锚点寄存器 offset (eval 加基址值用)


# VEX op 名 -> 语义 mnemonic
_OP_MNEM = {
    "INT_ADD": "add",
    "INT_SUB": "sub",
    "INT_AND": "and",
    "INT_OR": "orr",
    "INT_XOR": "eor",
    "INT_MULT": "mul",
    "INT_LEFT": "lsl",
    "INT_RIGHT": "lsr",
    "INT_SRIGHT": "asr",
    "INT_NEGATE": "not",
    "INT_LESS": "ltu",
    "INT_LESSEQUAL": "leu",
    "INT_SLESS": "lts",
    "INT_SLESSEQUAL": "les",
    "INT_EQUAL": "eq",
    "INT_NEQUAL": "ne",
    "INT_DIVS": "divs",
    "INT_DIVU": "divu",
}

# AArch64 条件码 (VEX guest_arm64_defs.h)
_COND_NAME = {
    0: "eq",
    1: "ne",
    2: "hs",
    3: "lo",
    4: "mi",
    5: "pl",
    6: "vs",
    7: "vc",
    8: "hi",
    9: "ls",
    10: "ge",
    11: "lt",
    12: "gt",
    13: "le",
    14: "al",
}


def decode_cc(packed: int) -> tuple[Optional[str], int]:
    """packed = (cond<<4)|cc_op -> (cond_name, cc_op)。"""
    cond = (packed >> 4) & 0xF
    op = packed & 0xF
    return _COND_NAME.get(cond), op


def emit_expr(ctx: LiftCtx, nid: int, depth: int = 0) -> Expr:
    """DFG 子图 -> Expr 树。ctx.expr 按节点缓存 (CSE)。"""
    if nid < 0 or depth > 100000:
        return Const(0)
    if nid in ctx.expr:
        return ctx.expr[nid]
    nodes = ctx.nodes
    n = nodes[nid]
    r = None

    if n.op == "CONST":
        r = Const(n.val)

    elif n.op == "LOAD" and n.ins:
        obj = mem_obj(ctx, n.ins[0])
        if obj is not None:
            objname, off, idxn = obj
            w = (n.out_size or 8) * 8
            if objname == "vreg":
                idx = emit_expr(ctx, idxn, depth + 1) if idxn is not None else None
                r = VregRead(idx=idx, off=off, width=w)
            else:
                r = Mem(objname, off, w)

    if r is None and reaches_anchor(ctx, nid):
        if n.op == "LOAD" and n.ins:
            r = Mem("mem", 0, (n.out_size or 8) * 8)  # 非锚点区域但可达锚点的 load
        elif n.op in ("COPY", "INT_SEXT") and n.ins:
            r = emit_expr(ctx, n.ins[0], depth + 1)
        elif n.op == "INT_ZEXT" and n.ins:
            r = ZExt(emit_expr(ctx, n.ins[0], depth + 1))
        elif n.op == "SUBPIECE" and n.ins:
            r = Trunc(emit_expr(ctx, n.ins[0], depth + 1))
        elif n.op == "INT_NEGATE" and n.ins:
            inner = emit_expr(ctx, n.ins[0], depth + 1)
            r = Op("not", [inner], bits=(n.out_size or 8) * 8)
        elif n.op == "INT_SELECT" and len(n.ins) == 3:
            r = fold_select(ctx, n, depth)
        elif n.op == "CC_COND":
            r = fold_cc(ctx, n, depth)
        elif n.op == "INT_ADD" and len(n.ins) == 2:
            # 锚点 + 偏移 -> PTR (博客: 绝对地址对象); 非锚点派生走普通 Op
            base = None
            base_off = None
            other = None
            for in_ in n.ins:
                hit = False
                for name, offv in _ANCHOR_OFF.items():
                    if is_direct_anchor(nodes, in_, offv):
                        base = {"x20": "ctx_s"}.get(name, _ANCHOR_NAME[name])
                        base_off = offv
                        hit = True
                        break
                if not hit:
                    other = in_
            if base is not None and other is not None:
                r = Ptr(base, emit_expr(ctx, other, depth + 1))
                r.base_off = base_off
            else:
                args = [emit_expr(ctx, i, depth + 1) for i in n.ins]
                r = Op(_OP_MNEM.get(n.op, "pc_" + n.op), args,
                       bits=(n.out_size or 8) * 8) if args else None
        elif n.op == "INPUT":
            r = Leaf(_REG_NAME.get(n.reg_off, "R%x" % n.reg_off), None)
        else:
            args = [emit_expr(ctx, i, depth + 1) for i in n.ins]
            mnem = _OP_MNEM.get(n.op, "pc_" + n.op)
            r = Op(mnem, args, bits=(n.out_size or 8) * 8) if args else None

    if r is None and n.has_val:
        r = Const(n.val)

    if r is None and n.op in ("COPY", "INT_SEXT") and n.ins:
        r = emit_expr(ctx, n.ins[0], depth + 1)
    if r is None and n.op == "INT_ZEXT" and n.ins:
        r = ZExt(emit_expr(ctx, n.ins[0], depth + 1))
    if r is None and n.op == "SUBPIECE" and n.ins:
        r = Trunc(emit_expr(ctx, n.ins[0], depth + 1))

    if r is None and n.op in _OP_MNEM and n.ins:
        args = [emit_expr(ctx, i, depth + 1) for i in n.ins]
        r = Op(_OP_MNEM[n.op], args, bits=(n.out_size or 8) * 8)

    if r is None and n.op == "INPUT":
        r = Leaf(_REG_NAME.get(n.reg_off, "R%x" % n.reg_off), None)

    if r is None and n.ins:
        r = emit_expr(ctx, n.ins[0], depth + 1)
    if r is None:
        r = Const(0)

    ctx.expr[nid] = r
    return r


def fold_cc(ctx: LiftCtx, n: Node, depth: int) -> Expr:
    """CC_COND(packed, d1, d2, nd) -> 比较运算 Expr 或 Const。

    packed = (cond<<4)|cc_op; cc_op=CMP(3) 时 d1 op d2。
    """
    nodes = ctx.nodes
    pn = nodes[n.ins[0]]
    if pn.has_val:
        cond_name, op = decode_cc(pn.val)
        if op == 3 and cond_name in ("hi", "hs", "lo", "ls", "eq", "ne"):
            a = emit_expr(ctx, n.ins[1], depth + 1)
            b = emit_expr(ctx, n.ins[2], depth + 1)
            rel = {
                "hi": "gtu",
                "hs": "geu",
                "lo": "ltu",
                "ls": "leu",
                "eq": "eq",
                "ne": "ne",
            }[cond_name]
            return Op(rel, [a, b], bits=64)
        if pn.has_val:
            return Const(pn.val)  # 已算出的条件值
    # 未知条件: 原样
    return Op("cc_cond", [emit_expr(ctx, i, depth + 1) for i in n.ins], bits=64)


def fold_select(ctx: LiftCtx, n: Node, depth: int) -> Expr:
    """INT_SELECT(cond, t, f) -> MAX/MIN/SLTU 或 Sel。

    cond 来自 CC_COND(hi/lo 等) 折叠成的比较; t/f 是分支值。
    """
    nodes = ctx.nodes
    cn = nodes[n.ins[0]]
    # 穿透 passthrough (64to1/COPY 包着 CC_COND)
    while cn.op in ("COPY", "INT_ZEXT", "INT_SEXT", "SUBPIECE") and cn.ins:
        cn = nodes[cn.ins[0]]
    # 解析 cond 为 (rel, a, b) 结构
    rel = None
    a = b = None
    if cn.op == "CC_COND":
        pn = nodes[cn.ins[0]]
        if pn.has_val:
            cond_name, op = decode_cc(pn.val)
            if op == 3:
                rel = {
                    "hi": "gtu",
                    "hs": "geu",
                    "lo": "ltu",
                    "ls": "leu",
                    "eq": "eq",
                    "ne": "ne",
                }.get(cond_name)
                a = emit_expr(ctx, cn.ins[1], depth + 1)
                b = emit_expr(ctx, cn.ins[2], depth + 1)
    t = emit_expr(ctx, n.ins[1], depth + 1)
    f = emit_expr(ctx, n.ins[2], depth + 1)
    bits = (n.out_size or 8) * 8
    if rel is not None:
        # cmp a,b; csel d,n,m,hi -> d = (a>b)?n:m = MAX(n,m)  (分支值折叠, 不需 t==a)
        if rel in ("gtu", "geu"):
            return Sel("MAX", t, f, bits)
        if rel in ("ltu", "leu"):
            return Sel("MIN", t, f, bits)
        # cset: (a<b)?1:0 -> sltu
        if isinstance(t, Const) and t.v == 1 and isinstance(f, Const) and f.v == 0:
            if rel == "ltu":
                return Op("sltu", [a, b], bits=bits)
            return Op(rel, [a, b], bits=bits)
        return Sel(rel, t, f, bits)
    return Sel("sel", t, f, bits)


def eq(x: Expr, y: Expr) -> bool:
    return x == y


# ---------------------------------------------------------------------------
# 化简 (常量折叠 + 代数简化 + ALIGN/MAX 惯用式)
# ---------------------------------------------------------------------------


def _match_sext(a: Expr, b: Expr) -> Optional[Expr]:
    """orr(and(asr(lsl(X,64-N),63), -mask), and(X,mask)) -> sextN(X)。

    lsl 56 + asr 63 把 X 的 bit7 提到 bit63 再算术填充, & -0x100 清低字节,
    orr 回低字节 -> 整字节符号扩展。N 由 lsl 移位量反推 (N = 64 - c1)。
    """
    for high, low in ((a, b), (b, a)):
        if not (isinstance(high, Op) and high.mnem == "and" and len(high.args) == 2
                and isinstance(high.args[1], Const)):
            continue
        asr = high.args[0]
        if not (isinstance(asr, Op) and asr.mnem == "asr" and len(asr.args) == 2
                and isinstance(asr.args[1], Const) and asr.args[1].v == 63):
            continue
        lsl = asr.args[0]
        if not (isinstance(lsl, Op) and lsl.mnem == "lsl" and len(lsl.args) == 2
                and isinstance(lsl.args[1], Const)):
            continue
        X = lsl.args[0]
        N = 64 - lsl.args[1].v
        c2 = high.args[1].v
        if N < 1 or N > 32 or c2 not in ((1 << 64) - (1 << N), -(1 << N)):
            continue
        mask = (1 << N) - 1
        # low = and(X, mask) 或 and(and(X, mask), mask)
        lowX = low
        if isinstance(low, Op) and low.mnem == "and" and len(low.args) == 2:
            if isinstance(low.args[1], Const) and low.args[1].v == mask:
                lowX = low.args[0]
        if lowX == X:
            return Op(f"sext{N}", [X], bits=64)
    return None


def _mask(bits: Optional[int]) -> int:
    return (1 << bits) - 1 if bits and bits < 64 else (1 << 64) - 1


def eval_expr(e: Expr, mem_vals=None) -> Optional[int]:
    if isinstance(e, Const):
        return e.v
    if isinstance(e, Leaf):
        return e.value if isinstance(e.value, int) else None
    if isinstance(e, Mem):
        return mem_vals.get((e.obj, e.off)) if mem_vals else None
    if isinstance(e, VregRead):
        return mem_vals.get(("vreg", e.off)) if mem_vals else None
    if isinstance(e, Op):
        if not e.args:
            return None
        args = [eval_expr(a, mem_vals) for a in e.args]
        if any(not isinstance(a, int) for a in args):
            return None
        return _eval_op(e.mnem, args, e.bits)
    if isinstance(e, Ptr):
        off = eval_expr(e.off, mem_vals) if e.off is not None else None
        base = mem_vals.get(("anchor", e.base_off)) if e.base_off is not None and mem_vals else None
        if isinstance(off, int) and isinstance(base, int):
            return (base + off) & ((1 << 64) - 1)
        return off if isinstance(off, int) else None
    if isinstance(e, Sel):
        a, b = eval_expr(e.a, mem_vals), eval_expr(e.b, mem_vals)
        if not isinstance(a, int) or not isinstance(b, int):
            return None
        if e.mnem == "MAX":
            return max(a, b) & _mask(e.bits)
        if e.mnem == "MIN":
            return min(a, b) & _mask(e.bits)
        return None
    if isinstance(e, ZExt):
        v = eval_expr(e.inner, mem_vals)
        return (v & 0xFFFFFFFF) if isinstance(v, int) else None
    if isinstance(e, Trunc):
        v = eval_expr(e.inner, mem_vals)
        return (v & 0xFFFFFFFF) if isinstance(v, int) else None
    return None


def _eval_op(mnem: str, args: list, bits: Optional[int]) -> int:
    m = _mask(bits)
    if not args:
        return 0
    a, b = args[0], args[1] if len(args) > 1 else None
    if mnem == "add":
        return (a + b) & m
    if mnem == "sub":
        return (a - b) & m
    if mnem == "and":
        return (a & b) & m
    if mnem == "orr":
        return (a | b) & m
    if mnem == "eor":
        return (a ^ b) & m
    if mnem == "mul":
        return (a * b) & m
    if mnem == "not":
        return (~a) & m
    if mnem == "lsl":
        return (a << (b & 0x3F)) & m
    if mnem == "lsr":
        return ((a & m) >> (b & 0x3F)) & m
    if mnem == "asr":
        return _const_shift(a, b, bits, arith=True)
    if mnem == "ltu":
        return int(a < b)
    if mnem == "leu":
        return int(a <= b)
    if mnem == "gtu":
        return int(a > b)
    if mnem == "geu":
        return int(a >= b)
    if mnem == "eq":
        return int(a == b)
    if mnem == "ne":
        return int(a != b)
    if mnem == "sltu":
        return int(a < b)
    if mnem == "align":
        return ((a + b - 1) & (-b)) & 0xFFFFFFFF
    if mnem == "divs":
        if b == 0:
            return 0
        return ((a // b) if a >= 0 else -((-a) // b)) & m
    if mnem == "divu":
        return (a // b) & m if b else 0
    if mnem.startswith("sext"):
        n = int(mnem[4:])
        mk = (1 << n) - 1
        v = a & mk
        if a & (1 << (n - 1)):
            v |= ~mk
        return v & m
    return 0


def _simplify_pass(e: Expr) -> Expr:
    """单遍自底向上化简 (子节点优先)。"""
    if isinstance(e, Op):
        args = [simplify(a) for a in e.args]
        if args and all(isinstance(a, Const) for a in args):
            return Const(_eval_op(e.mnem, [a.v for a in args], e.bits) & _mask(e.bits))
        ne = Op(e.mnem, args, bits=e.bits)
        return _simp_op(ne)
    if isinstance(e, ZExt):
        inner = simplify(e.inner)
        if isinstance(inner, Const):
            return Const(inner.v & 0xFFFFFFFF)
        if isinstance(inner, Trunc):
            return inner
        if inner.bits is not None and inner.bits >= 64:
            return inner
        return ZExt(inner)
    if isinstance(e, Trunc):
        inner = simplify(e.inner)
        if isinstance(inner, Const):
            return Const(inner.v & 0xFFFFFFFF)
        if isinstance(inner, Trunc):
            return inner
        if isinstance(inner, ZExt):
            return simplify(Trunc(inner.inner))
        if isinstance(inner, Op) and inner.mnem == "align" and inner.bits == 32:
            return inner
        # low32(x op c) = low32(x) op (c & 0xffffffff), 只对 64 位二元 op 分配
        if (
            isinstance(inner, Op)
            and inner.bits == 64
            and len(inner.args) == 2
            and inner.mnem in ("add", "sub", "and", "orr", "eor", "mul")
            and isinstance(inner.args[1], Const)
        ):
            a0 = simplify(Trunc(inner.args[0]))
            return Op(inner.mnem, [a0, Const(inner.args[1].v & 0xFFFFFFFF)], bits=32)
        return Trunc(inner)
    if isinstance(e, Sel):
        a, b = simplify(e.a), simplify(e.b)
        if e.mnem in ("MAX", "MIN") and isinstance(a, Const) and isinstance(b, Const):
            return Const(max(a.v, b.v) if e.mnem == "MAX" else min(a.v, b.v))
        return Sel(e.mnem, a, b, e.bits)
    return e


def simplify(e: Expr) -> Expr:
    """化简到不动点 (多次单遍直到无变化)。"""
    for _ in range(6):
        nxt = _simplify_pass(e)
        if nxt == e:
            break
        e = nxt
    return e


def _simp_op(e: Op) -> Expr:
    mnem, args, bits = e.mnem, e.args, e.bits
    if len(args) == 2:
        a, b = args
        if mnem == "orr":
            r = _match_sext(a, b)
            if r is not None:
                return r
        if isinstance(b, Const):
            if mnem == "and" and isinstance(a, Op) and a.mnem == "and" and len(a.args) == 2 \
                    and isinstance(a.args[1], Const):
                # and(and(x, c1), c2) = and(x, c1&c2)  (掩码吸收)
                return _simp_op(Op("and", [a.args[0], Const(a.args[1].v & b.v)], bits=bits))
            if (
                mnem == "add"
                and isinstance(a, Op)
                and a.mnem == "add"
                and len(a.args) == 2
                and isinstance(a.args[1], Const)
            ):
                # add(add(x, c1), c2) -> add(x, c1+c2)
                return simplify(
                    Op("add", [a.args[0], Const(a.args[1].v + b.v)], bits=bits)
                )
            if mnem in ("add", "orr", "eor") and b.v == 0:
                return a
            if mnem == "sub" and b.v == 0:
                return a
            if mnem == "and" and b.v == 0:
                return Const(0)
            if mnem == "mul" and b.v == 1:
                return a
            m = _mask(bits)
            if mnem == "and":
                if b.v == m:
                    return a  # and x, 全1 = x
                if bits == 64 and b.v == 0xFFFFFFFF:
                    return Trunc(a)  # 取低 32 位
            # ALIGN 惯用式: and(add(A, c1), c2), (c1+c2)&mask == mask -> align(A, -c2)
            if (
                mnem == "and"
                and isinstance(a, Op)
                and a.mnem == "add"
                and len(a.args) == 2
                and isinstance(a.args[1], Const)
            ):
                c1, c2 = a.args[1].v, b.v
                if ((c1 + c2) & m) == m and m != 0:
                    return Op("align", [a.args[0], Const((-c2) & m)], bits=bits)
                # 32 位掩码关系: A+B+0xffffffff 的 64 位 add 常量合并后, 符号位在低 32
                m32 = 0xFFFFFFFF
                if ((c1 + c2) & m32) == m32:
                    return Op("align", [a.args[0], Const((-c2) & m32)], bits=32)
        if isinstance(a, Const) and not isinstance(b, Const):
            if mnem in ("add", "and", "orr", "eor", "mul"):
                return _simp_op(Op(mnem, [b, a], bits=bits))
    if mnem == "not" and isinstance(args[0], Const):
        return Const((~args[0].v) & _mask(bits))
    return e


# ---------------------------------------------------------------------------
# 短 IR 渲染
# ---------------------------------------------------------------------------


def render_operand(e: Expr) -> str:
    e = simplify(e)
    if isinstance(e, Ptr):
        return f"&{e.obj}[{render_operand(e.off) if e.off else '?'}]"
    if isinstance(e, (ZExt, Trunc)):
        return render_operand(e.inner)
    if isinstance(e, VregRead):
        if e.idx is not None:
            return f"VM_REG[{render_operand(e.idx)}]"
        return f"VM_REG[{e.off:#x}]"
    if isinstance(e, Mem):
        if e.obj == "stack_ptr":
            return f"*STACK_PTR[+{e.off:#x}]"
        n = {"stack": "VM_STACK", "ctx": "CTX", "ctx_s": "CTX_S", "mem": "MEM"}.get(
            e.obj, e.obj
        )
        return f"{n}[{e.off:#x}]"
    if isinstance(e, Const):
        v = e.v
        bits = e.bits or 64
        if v & (1 << (bits - 1)):
            return f"#-0x{(1 << bits) - v:x}"
        return f"#{v:#x}"
    return str_expr(e)


def str_expr(e: Expr) -> str:
    if isinstance(e, Ptr):
        return f"PTR({e.obj}[{render_operand(e.off) if e.off else '?'}])"
    if isinstance(e, VregRead):
        return f"VM_REG[{e.off:#x}]"
    if isinstance(e, Mem):
        if e.obj == "stack_ptr":
            return f"*STACK_PTR[+{e.off:#x}]"
        n = {"stack": "VM_STACK", "ctx": "CTX", "ctx_s": "CTX_S", "mem": "MEM"}.get(
            e.obj, e.obj
        )
        return f"{n}[{e.off:#x}]"
    if isinstance(e, Leaf):
        return e.name
    if isinstance(e, Const):
        return f"{e.v:#x}"
    if isinstance(e, Op):
        args = ", ".join(render_operand(a) for a in e.args)
        return f"{e.mnem}{e.bits}({args})"
    if isinstance(e, Sel):
        return f"{e.mnem}{e.bits}({render_operand(e.a)}, {render_operand(e.b)})"
    if isinstance(e, ZExt):
        return f"zext32({str_expr(e.inner)})"
    if isinstance(e, Trunc):
        return f"low32({str_expr(e.inner)})"
    if isinstance(e, Const):
        return f"{e.v:#x}"
    return str(e)


_ALU = {
    "add": "add",
    "and": "and",
    "orr": "orr",
    "eor": "eor",
    "sub": "sub",
    "mul": "mul",
    "lsl": "lsl",
    "lsr": "lsr",
    "asr": "asr",
}


def render_value(dst: str, e: Expr) -> Optional[str]:
    """化简后的表达式 -> 一行短 IR; 未识别返回 None。"""
    e = simplify(e)
    if isinstance(e, Trunc):
        e = simplify(e)  # 让 low32 分配律展开
        if isinstance(e, Trunc):
            inner = e.inner
            if isinstance(inner, Const):
                return f"mov     {dst}, {render_operand(e)}"
            return render_value(dst, inner)
    if isinstance(e, ZExt):
        return render_value(dst, e.inner)
    if isinstance(e, VregRead):
        return f"mov     {dst}, {render_operand(e)}"
    if isinstance(e, Mem):
        return f"mov     {dst}, {render_operand(e)}"
    if isinstance(e, Const):
        return f"mov     {dst}, {render_operand(e)}"
    if isinstance(e, Leaf):
        return f"mov     {dst}, {render_operand(e)}"
    if isinstance(e, Ptr):
        return f"mov     {dst}, {render_operand(e)}"
    if isinstance(e, Sel):
        if e.mnem in ("MAX", "MIN"):
            return f"{e.mnem}     {dst}, {render_operand(e.a)}, {render_operand(e.b)}"
        return None
    if isinstance(e, Op):
        if e.mnem == "not" and len(e.args) == 1:
            inner = e.args[0]
            if (
                isinstance(inner, Op)
                and inner.mnem in ("orr", "and")
                and len(inner.args) == 2
            ):
                m = "nor" if inner.mnem == "orr" else "nand"
                return f"{m}     {dst}, {render_operand(inner.args[0])}, {render_operand(inner.args[1])}"
            return f"not     {dst}, {render_operand(inner)}"
        if e.mnem == "sub" and len(e.args) == 2:
            return f"sub     {dst}, {render_operand(e.args[0])}, {render_operand(e.args[1])}"
        if e.mnem == "sltu" and len(e.args) == 2:
            return f"sltu    {dst}, {render_operand(e.args[0])}, {render_operand(e.args[1])}"
        if e.mnem.startswith("sext") and len(e.args) == 1:
            return f"{e.mnem}    {dst}, {render_operand(e.args[0])}"
        if e.mnem in _ALU and len(e.args) == 2:
            return f"{_ALU[e.mnem]}     {dst}, {render_operand(e.args[0])}, {render_operand(e.args[1])}"
        if e.mnem == "align":
            return f"align{e.bits} {dst}, {render_operand(e.args[0])}, {render_operand(e.args[1])}"
        # 比较等未映射形态: 保留结构
        return (
            f"{e.mnem}{e.bits}    {dst}, {render_operand(e.args[0]) if e.args else ''}"
        )
    return None


def collect_mem_vals(ctx, anchor_entry=None):
    """LOAD 节点的具体值 -> {(obj, off): value} (校验用), 含锚点基址。"""
    vals = {}
    for i, n in enumerate(ctx.nodes):
        if n.op == "LOAD" and n.has_val and n.ins:
            obj = mem_obj(ctx, n.ins[0])
            if obj is not None:
                vals[(obj[0], obj[1])] = n.val
    if anchor_entry:
        for offv, v in anchor_entry.items():
            vals[("anchor", offv)] = v
    return vals


def lift_one(dst, expr, val, mem_vals=None) -> str:
    ir = render_value(dst, expr)
    if ir is None:
        ir = f"store   {dst}, {str_expr(simplify(expr))}"
    if val is not None:
        ir += f"  // = 0x{val:x}"
        ev = eval_expr(expr, mem_vals)
        if isinstance(ev, int):
            ir += (
                "  [✓]"
                if (ev & ((1 << 64) - 1)) == (val & ((1 << 64) - 1))
                else f"  [✗ got 0x{ev & ((1 << 64) - 1):x}]"
            )
    return ir


_SO_PATH = "/home/duck/NewCode/Projects/DuckReVM/libksxgs.so"
_dynsym_cache = None


def _load_dynsym(path: str) -> dict[int, str]:
    """.dynsym 定义的 FUNC 符号 -> {addr: name} (pyelftools, 懒加载)。"""
    global _dynsym_cache
    if _dynsym_cache is not None:
        return _dynsym_cache
    _dynsym_cache = {}
    try:
        from elftools.elf.elffile import ELFFile

        with open(path, "rb") as f:
            elf = ELFFile(f)
            ds = elf.get_section_by_name(".dynsym")
            if ds is not None:
                for sym in ds.iter_symbols():
                    if sym["st_info"]["type"] == "STT_FUNC" and sym["st_value"]:
                        _dynsym_cache[sym["st_value"]] = sym.name
    except Exception:
        pass
    return _dynsym_cache


def detect_calls(insts: list[dict]) -> list[tuple[str, Optional[int]]]:
    """bl/blr 指令 -> [(bl 地址, helper 入口地址)]。

    helper 入口 = bl 后第一条指令的 off (trace 会跟进 helper 体)。
    """
    calls = []
    for i, inst in enumerate(insts):
        mnem = inst["asm"].strip().lower()
        if mnem.startswith("bl") and i + 1 < len(insts):
            try:
                target = int(insts[i + 1]["off"], 16)
            except (ValueError, KeyError):
                target = None
            calls.append((inst["off"], target))
    return calls


def resolve_sym(target: Optional[int]) -> Optional[str]:
    if target is None:
        return None
    return _load_dynsym(_SO_PATH).get(target)


def lift_handler(insts: list[dict]) -> list[str]:
    """一条 handler 指令序列 -> IR 行列表。"""
    nodes, roots, anchor_entry = build_dfg(insts)
    propagate_values(nodes)
    ctx = LiftCtx(nodes)
    mem_vals = collect_mem_vals(ctx, anchor_entry)
    outs = []
    for _, target in detect_calls(insts):
        if target is not None:
            sym = resolve_sym(target)
            outs.append(f"// call @0x{target:x}" + (f"  ; {sym}" if sym else ""))
    for r in roots:
        st = nodes[r]
        try:
            if len(st.ins) < 2:
                continue
            addr = st.ins[0]
            val_n = st.ins[1]
            obj = mem_obj(ctx, addr)
            if obj is None:
                continue  # 非锚点区域写 (机器码/解码链), 跳过
            objname, off, _ = obj
            dst = {
                "vreg": f"VM_REG[{off:#x}]",
                "stack": f"VM_STACK[{off:#x}]",
                "ctx": f"CTX[{off:#x}]",
                "ctx_s": f"CTX_S[{off:#x}]",
                "stack_ptr": f"*STACK_PTR[+{off:#x}]",
            }.get(objname)
            if dst is None:
                continue
            expr = emit_expr(ctx, val_n)
            val = None
            if val_n >= 0 and nodes[val_n].has_val:
                val = nodes[val_n].val
            outs.append(lift_one(dst, expr, val, mem_vals))
        except Exception as e:
            outs.append(f"; STORE 根 {r} 展开失败: {e}")
    return outs


# ---------------------------------------------------------------------------
# Interpreter 入口
# ---------------------------------------------------------------------------


class Interpreter:
    """VEX -> DFG -> 短 IR 解释器 (对齐 lift_pypcode 的 LiftHandlerInterpreter)。"""

    def __init__(self) -> None:
        self.arch = _ARCH

    def analyze(self, handler: list[dict]) -> list[str]:
        """对切出的 handler 指令列表做还原, 返回短 IR 行。"""
        return lift_handler(handler)
