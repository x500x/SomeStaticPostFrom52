from .interpreter import Interpreter
from .parse import TraceParser


class Matcher:
    def __init__(self, Parser: TraceParser, interpreter: Interpreter) -> None:
        self.parser = Parser
        self.interpreter = interpreter
        self.cur_handler = []  # 当前 handler 的累积缓冲
        self.handlers = []  # 切出的完整 handler 段（每段是一个 inst dict 列表）
        self.vm_stack = []
        self.current_vm_depth_ = 0
        self.funcStart = []
        self.funcEnd = []

    @staticmethod
    def _asm(inst: dict) -> str:
        return inst["asm"].lower().replace(" ", "")

    def split(self):
        """只切 handler 段, 不解释。返回 self.handlers (已掐头去尾)。"""
        # 寄存器级数据流：reg -> 最后一次写入该寄存器的指令 asm
        last_writer: dict[str, str] = {}

        for k, inst in enumerate(self.parser.iter_atomic_objects()):
            try:
                if inst is None:
                    raise ValueError("inst is None, expected non-null JSON object")
                asm = self._asm(inst)

                # 分发 br 判定：br xR 且 R 上次由 add R, x25, R 写入
                # （x25 = handler 表基址，add xR,x25,xR 即计算下一个 handler 地址）
                # 不要求连续——复合 handler 里可能是 add->ret->br 的非连续形态
                is_dispatch = False
                if asm.startswith("br"):
                    reg = asm[2:].split(",")[0].strip()
                    if (
                        reg.startswith("x")
                        and last_writer.get(reg) == f"add{reg},x25,{reg}"
                    ):
                        is_dispatch = True

                if is_dispatch:
                    # 当前 handler 到此 br 结束（br 属于上一个 handler 的尾块）
                    self.cur_handler.append(inst)
                    self.handlers.append(self.cur_handler)
                    self.cur_handler = []
                    # handler 边界：清空寄存器写者，避免上一段的 add xR,x25,xR
                    # 泄漏到下一段，导致 br xR 被误判为 dispatch
                    last_writer.clear()
                else:
                    self.cur_handler.append(inst)

                # 更新寄存器写者（写列里所有寄存器）
                for r in inst.get("write", {}):
                    lr = r.lower()
                    if lr.startswith("x") or lr.startswith("w"):
                        last_writer[lr] = asm

            except ValueError as ve:
                print(k, ve)
                break

        # trace 末尾未截断的尾巴（如 VM 退出后的代码）
        if self.cur_handler:
            self.handlers.append(self.cur_handler)

        self.handlers = self.handlers[1:-1]
        return self.handlers

    def match(self):
        self.split()
        # 统一解释每一段切出的 handler (VEX -> DFG -> 短 IR)
        for k, h in enumerate(self.handlers):
            for line in self.interpreter.analyze(h):
                print(line)
            break

    def report(self):
        print(f"共切出 {len(self.handlers)} 段")
        for i, h in enumerate(self.handlers):
            entry = h[0]
            end = h[-1]
            print(
                f"入口 = {entry['off']:<10} {entry['asm']!r:42} "
                f"末尾 = {end['off']:<10} {end['asm']!r:30} 指令数 = {len(h)}"
            )
