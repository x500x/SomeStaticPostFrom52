"""DFG 分析驱动: 切 handler -> VEX DFG -> 短 IR。

用法: .venv/bin/python analyze.py [N]   (N = 分析的 handler 个数, 默认 1)
"""
import sys

from src.parse import TraceParser
from src.matcher import Matcher
from src.interpreter import Interpreter
from src.interpreter import build_dfg, propagate_values, LiftCtx, mem_obj


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    parser = TraceParser("./trace_logs/code.log")
    interpreter = Interpreter()
    matcher = Matcher(parser, interpreter)
    handlers = matcher.split()
    print(f"共切出 {len(handlers)} 段, 分析前 {n} 段\n")

    for k, h in enumerate(handlers[:n]):
        for line in interpreter.analyze(h):
            print(line)
        print()

    # 统计: 锚点 store 数 / 可校验数 / 校验通过数
    n_ok = n_noval = n_wrong = n_sink = 0
    for h in handlers[:n]:
        nodes, roots, anchor_entry = build_dfg(h)
        propagate_values(nodes)
        ctx = LiftCtx(nodes)
        from src.interpreter import collect_mem_vals, emit_expr, eval_expr
        mv = collect_mem_vals(ctx, anchor_entry)
        for r in roots:
            st = nodes[r]
            if len(st.ins) < 2 or mem_obj(ctx, st.ins[0]) is None:
                continue
            n_sink += 1
            v = st.ins[1]
            val = nodes[v].val if v >= 0 and nodes[v].has_val else None
            ev = eval_expr(emit_expr(ctx, v), mv)
            if isinstance(val, int) and isinstance(ev, int):
                if (ev & ((1 << 64) - 1)) == (val & ((1 << 64) - 1)):
                    n_ok += 1
                else:
                    n_wrong += 1
            else:
                n_noval += 1
    print(f"统计: sink {n_sink} 行 | 可校验 {n_ok + n_wrong} (✓ {n_ok} / ✗ {n_wrong}) | 无值可校验 {n_noval}")


if __name__ == "__main__":
    main()
