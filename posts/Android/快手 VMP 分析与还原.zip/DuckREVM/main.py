from src.parse import TraceParser
from src.matcher import Matcher
from src.interpreter import Interpreter


def main():
    Parser = TraceParser("./trace_logs/code.log")
    interpreter = Interpreter()
    matcher = Matcher(Parser, interpreter)
    matcher.match()


if __name__ == "__main__":
    main()
