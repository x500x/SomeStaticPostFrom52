# DuckReVM — VM 结构与 handler 分析

> 基于 `trace_logs/code.log`(AARCH64 原生指令 trace)的 25558 个 handler 切片统计。
> 数据来源:每条 trace 行含 `seq/pc/off/asm/read/write/extra`,`read`/`write` 是寄存器级的具体值。

## 1. VM 寄存器约定

三个锚点寄存器出现在 ~99.9% 的 handler 入口(读于本段定义之前,即跨 handler 持久)。

**判定方法与置信度**:

| 寄存器 | 证据 | 置信度 |
|---|---|---|
| `x25` | dispatch `add xR,x25,xR` 共 25559 次,x25 **100% 恒定** `0x7450c573a4`,其中 99.4% 的下一条 `br xR` 目标 == x25+偏移 == 实际执行的下一条地址 | 结构性事实(实锤) |
| `x21` | `[x21,xN]` 访问基址仅 3 种(跨 3 次 VM 运行),单次运行内恒定;索引 xN 是 bytecode 提供的 37 种小整数;访问形态为随机读写操作数(ldr/str + 读改写) | 结构事实扎实;**"vreg 文件"语义名是推断**(模式吻合 VM 寄存器文件的通行定义) |

**重要**:x25/x21 的基址值**不是全局常量**——它们只在使用场景内恒定,且会随 VM 运行变化(x21 有 3 个基址)。
DFG 必须**每个 handler 从 trace 首指令的 read 列动态解析基址值,不能硬编码**。

| 寄存器 | 角色 | 证据 |
|---|---|---|
| `x26` | bytecode 指针 (vpc) | 25550/25558 handler 入口;`ldrsh/ldr xN, [x26, #off]` 取操作数,`add x26, x26, #imm` 推进 |
| `x25` | handler 表基址 | 25519 入口;dispatch 的 `add x8, x25, x8` |
| `x21` | vreg 文件基址 | 25455 入口;`ldr/str xN, [x21, xM]` 读写虚拟寄存器 |

两个条件指针(仅用到栈/上下文的 handler):

| 寄存器 | 角色 | 证据 |
|---|---|---|
| `sp` | vm 栈 | 3581 入口;典型首次读是 `bl`(压栈) |
| `x23` / `x20` | ctx 基址 / ctx 结构指针 | 3516 / 3474 入口;`add x0, x23, x8`、`mov x1, x20`、`ldr x8, [x20, #0x70]` |

其余 `x19-x28`、`fp`、`lr` 主要是 handler prologue 的 `stp` 保存/恢复(50~170 handler),
是调用者保存的 scratch,不是 VM 上下文。

## 2. Bytecode 布局(注意:宽度不固定)

bytecode 指令按 **8 字节对齐的槽位**组织,但**操作数宽度由 opcode 家族决定**,不能假定统一宽度。

实测 `[x26]` 访问形态分布(次数降序):

| 形态 | 次数 | 语义 |
|---|---|---|
| `ldrsh [x26]` | 24516 | sx16,槽位 0(最常见) |
| `ldrsh [x26, #0x8]` | 22907 | sx16 |
| `ldrsh [x26, #0x10]` | 11583 | sx16 |
| `ldr wN, [x26, #0x10]` | 9540 | **u32**,同一槽位不同家族读 32bit |
| `ldrsh [x26, #0x18]` | 2496 | sx16 |
| `ldrsh [x26, #0x20]` | 2460 | sx16 |
| `ldr xN, [x26, #0x18]` | 1432 | **u64** |
| `ldr xN, [x26, #0x8]` | 1286 | **u64** |
| `ldrh / ldrb / ldp / ldr [x26]` | 少量 | u16 / u8 / 64bit pair / 64bit 直读 |

**vpc 推进量分布**:`+=0x20` ×17414、`+=0x18` ×3913、`+=0x30` ×2465、`+=0x28` ×580
→ 指令长度可变(0x18~0x30),部分 handler 还有非 `add x26,x26,#imm` 的推进方式(如 `add x26, x0, #0x8`)。

例(MAX 类 handler 的 bytecode 指令,长 0x20):

```
槽位0    ldrsh x10, [x26]        ← sx16  vreg 索引 (如 0x90)
槽位8    ldr   x9,  [x26, #0x8]  ← u64   操作数
槽位0x10 ldr   w9,  [x26, #0x10] ← u32   操作数
推进     add   x26, x26, #0x20
```

## 3. Handler 三种形态

```
handler#0   MAX 类   (23 条): 入口 sp,x21,x25,x26 → 读 bytecode[0/8/0x10] + vm_stack + vreg
                              → 写 vreg[0x90] + 栈指针指向的地址
handler#30  最短    (5 条) : 入口 x25,x26 → 只读 bytecode、算下一 handler → 纯 dispatch,不碰 vreg/栈
handler#244 含 bl   (18 条): 入口 sp,x21,x23,x25,x26 → 读 3 个 bytecode 操作数 + 3 个 vreg → 调 helper
```

- 部分 handler 带 prologue(`stp x19-x28, ... [sp, #-N]!`),用大量 scratch 寄存器。
- 部分 handler 调 helper:`ldr x17, [x16, #0xf38]`(固定地址函数指针)再 `bl`。
  这类 handler **重汇编重执行会断**(`bl` 目标重定基后是野地址),但 **trace 上的反向污点不受影响**。

## 4. DFG / 反向污点设计要点

**跟踪的寄存器集**:

```
锚点指针(每个 handler 入口从首指令 read 列取具体值): x21, x25, x26, sp, x23, x20
内存对象(源/汇,按具体地址 key):
  vreg_file  = [x21 + 操作数]      ← 源(读)与汇(写)都有
  bytecode   = [x26 + #off]        ← 源(立即数/操作数)
  vm_stack   = [sp + #off]         ← 源与汇都有
  ctx_struct = [x23 + #off], [x20 + #off]
scratch(污点穿过、不设根): x0-x18, x8-x11 ...
```

**反向污点**:汇(sink)= 对 vreg_file / vm_stack / ctx 的 `str`;源(source)= 对 bytecode / vreg_file / vm_stack 的 `ldr`。

**硬约束**:

1. **W/X 必须统一**:ARM64 写 `w8` 即定义 `x8`。实测不统一会漏依赖
   (handler#0 的 `ldr w8` 定义 x8,被误判成"入口寄存器")。这是 DFG 的第一条规则。
2. **bytecode 宽度不固定**:从每条 load 的实际 mnemonic + 目标寄存器宽度推出操作数宽度
   (`ldrsh`=sx16、`ldr w`=u32、`ldr x`=u64、`ldrh`=u16、`ldrb`=u8)。
   不要硬编码某个槽位是几字节。
3. **handler 结尾的 dispatch**(`add x8, x25, x8` + `br x8`)step 时无后继:
   语义恢复要切掉 dispatch 尾巴再执行,或读 `all_successors[0]`。

## 5. 已验证的事实

- VEX 与 P-code 对相同汇编产出完全一致的 IR(两个不同地址的重复 handler,IR 哈希相同)。
- `load_shellcode` 传汇编字符串自动走 `arch.asm()`(keystone),多行地址自动递增,
  与逐条汇编字节一致,无需手写汇编循环。
- `load_shellcode` 的 entry_point 默认 `start_offset=0`,blob 映射在 `base_addr`,
  需手动 `state.ip = base_addr`,否则 step 会从 0x0 取指令。
